import { useEffect, useRef, useState } from 'react'
import { COURSE } from './data/course.js'
import * as P from './logic/progress.js'

// Date ko padhne layak format mein badalta hai ye:
export const fmt = iso => new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })

// Progress bar: percent ke hisaab se ki kitna kiya abhi:
export function Ring({ percent }) {
  return <div className="bar"><progress value={percent} max="100" aria-label="Course progress" /> <strong>{percent}%</strong></div>
}

/** The chain: each module is a block linked to the previous one; a block seals when its quiz is passed. */
// Left side ki list: modules, lessons aur quiz. Locked items disabled rehte hain
export function ChainNav({ s, view, go }) {
  return (<nav className="chain" aria-label="Course modules">
    {COURSE.modules.map((m, i) => {
      const open = P.isModuleUnlocked(s, m.id), sealed = P.isQuizPassed(s, m.id)
      return (<section key={m.id} className={`block ${sealed ? 'sealed' : open ? 'open' : 'locked'}`} aria-labelledby={`h-${m.id}`}>
        <h2 id={`h-${m.id}`}><span className="idx">#{i + 1}</span> {m.title}
          <span className="state">{sealed ? 'Sealed' : open ? 'Open' : 'Locked'}</span></h2>
        {!open && <p className="why">Pass the quiz in “{COURSE.modules[i - 1].title}” to unlock.</p>}
        <ul>
          {m.lessons.map(l => {
            const un = P.isLessonUnlocked(s, l.id), cur = view.t === 'lesson' && view.id === l.id
            return (<li key={l.id}><button disabled={!un} aria-current={cur ? 'page' : undefined} onClick={() => go({ t: 'lesson', id: l.id })}>
              <i className={P.isLessonDone(s, l.id) ? 'dot done' : 'dot'} aria-hidden="true" />{l.title}
              <span className="sr">{P.isLessonDone(s, l.id) ? ' (completed)' : un ? '' : ' (locked)'}</span></button></li>)
          })}
          <li><button disabled={!P.isQuizUnlocked(s, m.id)} aria-current={view.t === 'quiz' && view.id === m.id ? 'page' : undefined} onClick={() => go({ t: 'quiz', id: m.id })}>
            <i className={sealed ? 'dot done sq' : 'dot sq'} aria-hidden="true" />Module quiz{P.attemptsOf(s, m.id).length ? ` · best ${P.bestScore(s, m.id)}%` : ''}
            <span className="sr">{P.isQuizUnlocked(s, m.id) ? '' : ' (locked)'}</span></button></li>
        </ul></section>)
    })}
    <button className="final" aria-current={view.t === 'cert' ? 'page' : undefined} onClick={() => go({ t: 'cert' })}>
      Certificate {P.certificateEligibility(s).eligible ? '— ready' : ''}</button>
  </nav>)
}

// Ek lesson ka page: Read, then 'complete' press karo; next lesson ya quiz ka button dikhega:
export function LessonView({ s, lesson, mod, onComplete, go }) {
  const un = P.isLessonUnlocked(s, lesson.id), done = P.isLessonDone(s, lesson.id)
  const idx = mod.lessons.findIndex(l => l.id === lesson.id), next = mod.lessons[idx + 1]
  const was = useRef(done), after = useRef(null)
  useEffect(() => { if (done && !was.current) after.current?.focus(); was.current = done }, [done])  // keep keyboard focus when the button it was on disappears
  if (!un) return <Panel title={lesson.title}><p className="note warn" role="alert">This lesson is locked. Complete the earlier lessons and pass the previous module quiz.</p></Panel>
  return (<Panel title={lesson.title} kicker={`${mod.title} · lesson ${idx + 1} of ${mod.lessons.length}`}>
    {lesson.body.map((p, i) => <p key={i}>{p}</p>)}
    <div className="actions">
      {!done && <button className="btn primary" onClick={() => onComplete(lesson.id)}>Mark lesson complete</button>}
      {done && <p className="note ok" role="status">Lesson complete.</p>}
      {done && (next ? <button ref={after} className="btn" onClick={() => go({ t: 'lesson', id: next.id })}>Next lesson</button>
        : <button ref={after} className="btn primary" onClick={() => go({ t: 'quiz', id: mod.id })}>Take the module quiz</button>)}
    </div></Panel>)
}

// Quiz page: saare answers dene ke baad hi submit chalega; result ke baad retry kar sakte hain
export function QuizView({ s, mod, onSubmit }) {
  const [answers, setAnswers] = useState(Array(mod.quiz.length).fill(null))
  const [graded, setGraded] = useState(null), res = useRef(null)
  useEffect(() => { if (graded) res.current?.focus() }, [graded])
  const unlocked = P.isQuizUnlocked(s, mod.id), hist = P.attemptsOf(s, mod.id)
  if (!unlocked) return <Panel title={`${mod.title} quiz`}><p className="note warn" role="alert">Finish every lesson in this module first.</p></Panel>
  const ready = answers.every(a => a !== null)
  const submit = () => { const g = onSubmit(mod.id, answers); if (g) setGraded(g) }
  const retry = () => { setAnswers(Array(mod.quiz.length).fill(null)); setGraded(null) }
  return (<Panel title={`${mod.title} quiz`} kicker={`Pass mark ${COURSE.passMark}% · ${mod.quiz.length} questions`}>
    {graded && <div ref={res} tabIndex={-1} className={`note ${graded.passed ? 'ok' : 'warn'}`} role="status">
      <strong>{graded.correct} / {graded.total} correct ({graded.pct}%).</strong> {graded.passed ? 'Passed. The next block is unlocked.' : `Below ${COURSE.passMark}%. Review the explanations and try again.`}</div>}
    {mod.quiz.map((q, i) => (<fieldset key={i} disabled={!!graded}>
      <legend>{i + 1}. {q.q}</legend>
      {q.options.map((o, j) => {
        const r = graded?.results[i]; const cls = r ? (j === r.answer ? 'right' : j === r.chosen ? 'wrong' : '') : ''
        return (<label key={j} className={`opt ${cls}`}><input type="radio" name={`q${i}`} checked={answers[i] === j} onChange={() => setAnswers(a => a.map((v, k) => (k === i ? j : v)))} />{o}
          {cls === 'right' && <span className="sr"> (correct answer)</span>}{cls === 'wrong' && <span className="sr"> (your answer, incorrect)</span>}</label>)
      })}
      {graded && <p className="why-a">{graded.results[i].ok ? 'Correct. ' : 'Not quite. '}{q.why}</p>}
    </fieldset>))}
    <div className="actions">
      {!graded ? <button className="btn primary" disabled={!ready} onClick={submit}>Submit answers</button>
        : <><button className="btn primary" onClick={retry}>{graded.passed ? 'Retake for a better score' : 'Retry quiz'}</button></>}
      {!graded && !ready && <span className="hint">Answer all {mod.quiz.length} questions to submit.</span>}
    </div>
    <h3>Attempt history</h3>
    {hist.length === 0 ? <p className="hint">No attempts yet.</p> :
      <ol className="hist">{hist.map((a, i) => <li key={i}>Attempt {i + 1}: {a.score}/{a.total} ({a.pct}%) <b className={a.passed ? 'tag ok' : 'tag bad'}>{a.passed ? 'passed' : 'failed'}</b> <time dateTime={a.at}>{fmt(a.at)}</time></li>)}</ol>}
    {hist.length > 0 && <p className="hint">Best score: {P.bestScore(s, mod.id)}%</p>}
  </Panel>)
}

// Certificate page: eligible na ho to baaki kaam ki list dikhata hai yaha pe:
export function CertificateView({ s, onIssue, onDownload, onReset }) {
  const el = P.certificateEligibility(s)
  const [name, setName] = useState(s.learner), [err, setErr] = useState(''), [busy, setBusy] = useState(false)
  const c = s.certificate
  const issue = async e => { e.preventDefault(); setBusy(true); setErr(''); const m = await onIssue(name); if (m) setErr(m); setBusy(false) }
  return (<Panel title="Completion certificate" kicker={el.eligible ? 'Every lesson done, every quiz passed' : 'Not yet eligible'}>
    {!el.eligible && <div className="note warn" role="status"><p>Complete these to unlock your certificate:</p><ul>{el.reasons.map(r => <li key={r}>{r}</li>)}</ul></div>}
    {el.eligible && !c && <form onSubmit={issue} noValidate>
      <label htmlFor="nm">Name to print on the certificate</label>
      <input id="nm" value={name} onChange={e => setName(e.target.value)} maxLength={80} autoComplete="name" aria-invalid={!!err} aria-describedby="nm-e" />
      <p id="nm-e" className="err" role="alert">{err}</p>
      <button className="btn primary" disabled={busy}>{busy ? 'Hashing…' : 'Issue certificate'}</button></form>}
    {c && <>
      <article className="cert" aria-label="Certificate">
        <p>{COURSE.issuer}</p><h3>Certificate of Completion</h3><p>This certifies that</p><p className="who">{c.name}</p>
        <p>completed <b>{COURSE.title}</b>: {P.getProgress(s).lessonTotal} lessons and {P.getProgress(s).quizTotal} quizzes at {COURSE.passMark}%+.</p>
        <p>Completed <time dateTime={c.issuedAt}>{fmt(c.issuedAt)}</time></p>
        <code title="SHA-256 of the content below">SHA-256 {c.hash}</code>
        <details><summary>Hashed content (re-hash it to verify)</summary><pre>{c.content}</pre></details></article>
      <div className="actions"><button className="btn primary" onClick={() => onDownload(c)}>Download certificate</button>
        <button className="btn" onClick={() => window.print()}>Print / save as PDF</button></div></>}
    <div className="actions end"><button className="btn ghost" onClick={onReset}>Reset all progress</button></div>
  </Panel>)
}

// Har page ka common block (heading + content):
function Panel({ title, kicker, children }) {
  return <article className="panel">{kicker && <p className="kicker">{kicker}</p>}<h1 tabIndex={-1} id="main-h">{title}</h1>{children}</article>
}
