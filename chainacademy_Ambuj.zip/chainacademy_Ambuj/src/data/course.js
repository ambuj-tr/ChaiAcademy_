const Q = (q, options, answer, why) => ({ q, options, answer, why })
const L = (id, title, body) => ({ id, title, body })

export const COURSE = {
  id: 'chainacademy-web3-foundations',
  title: 'Web3 Foundations',
  issuer: 'Blockchain Students Chapter',
  passMark: 75,
  modules: [
    { id: 'm1', title: 'Blockchain Foundations', blurb: 'Ledgers, hashes and how strangers agree.',
      lessons: [
        L('m1l1', 'Ledgers, blocks and hashes', ['A blockchain is an append-only ledger grouped into blocks. Every block header contains the hash of the previous block, which chains them together.', 'A cryptographic hash turns any input into a fixed-size fingerprint. Change one character of the input and the output changes completely, so tampering with old history is instantly visible.']),
        L('m1l2', 'Consensus without a boss', ['Nodes must agree on one history without a central authority. Proof of Work ranks history by computation spent; Proof of Stake ranks it by collateral locked up by validators.', 'Attacks such as a 51% attack work by controlling a majority of consensus power so that recent history can be rewritten. Decentralisation makes this expensive.'])],
      quiz: [
        Q('What links one block to the block before it?', ['A shared password', "The previous block's hash", 'Only the timestamp', "A miner's username"], 1, "Each header stores the previous block's hash, so editing history changes every later hash."),
        Q('Which is a property of a cryptographic hash?', ['It can be reversed with a key', 'Output length grows with input', 'A tiny input change gives a completely different output', 'It always outputs zeros'], 2, 'This avalanche effect is what makes tampering detectable.'),
        Q('Proof of Stake chooses validators mainly by…', ['Computation performed', 'Capital staked as collateral', 'Account age', 'Public votes'], 1, 'Validators put capital at risk and can be penalised (slashed) for misbehaviour.'),
        Q('What does a 51% attack require?', ['Hacking 51 wallets', 'A fork after 51 blocks', 'Fees rising by 51%', 'Majority control of consensus power'], 3, 'With a majority an attacker can reorder or rewrite recent blocks.')] },
    { id: 'm2', title: 'Wallets & Cryptography', blurb: 'Keys, signatures and self-custody.',
      lessons: [
        L('m2l1', 'Keys and signatures', ['A wallet holds a key pair. The private key signs transactions; the public key (and the address derived from it) lets anyone verify that signature.', 'A signature proves the holder of the private key approved this exact message, without revealing the key.']),
        L('m2l2', 'Wallets and self-custody', ['A seed phrase is a human-readable backup from which all of a wallet\u2019s keys derive. Anyone who has it controls the funds.', 'With custodial wallets a company holds the keys. "Not your keys, not your coins" means the custodian, not you, controls the assets.'])],
      quiz: [
        Q('Which key signs a transaction?', ['Private key', 'Public key', 'Address', 'Block hash'], 0, 'Only the private key can produce a valid signature; the public key verifies it.'),
        Q('What is a seed phrase?', ['A password an exchange can reset', 'A public address', 'A transaction hash', 'A backup from which all keys derive'], 3, 'Whoever has the phrase controls every key derived from it. Never share it.'),
        Q('A digital signature proves…', ['The wallet has funds', 'The network fee was paid', 'The key holder approved this exact message', "The recipient's identity"], 2, 'It binds the approval to the message content and the key.'),
        Q('"Not your keys, not your coins" means…', ['A custodian controls the coins', 'Keys are optional', 'Hardware wallets hold no coins', 'Coins only exist off-chain'], 0, 'Control of the private keys is control of the assets.')] },
    { id: 'm3', title: 'Smart Contracts & Ethereum', blurb: 'Programs that live on-chain.',
      lessons: [
        L('m3l1', 'What a smart contract is', ['A smart contract is code deployed on a blockchain that runs deterministically when called: every node gets the same result from the same input.', 'Deployed code cannot simply be edited. Upgradeability must be designed in, for example with proxy patterns.']),
        L('m3l2', 'Gas and the EVM', ['The Ethereum Virtual Machine executes contract bytecode. Each operation costs gas, so users pay for computation and infinite loops cannot stall the network.', 'Reentrancy is a classic bug: an external call lets another contract call back in before state is updated.'])],
      quiz: [
        Q('What is a smart contract?', ['A legal PDF stored on-chain', 'Code on-chain that executes deterministically', 'A wallet backup', 'A mining pool'], 1, 'The same inputs yield the same outputs on every node.'),
        Q('Gas measures…', ['Network speed', 'Block size in MB', 'Computational work paid for', 'Wallet balance'], 2, 'Gas prices each EVM operation and bounds execution.'),
        Q('Why can\u2019t a deployed contract just be edited?', ['Code on-chain is immutable unless upgrade patterns were built in', 'Miners forbid it', 'It is encrypted', 'Only exchanges may edit'], 0, 'Immutability is a core property; proxies are used for upgrades.'),
        Q('Reentrancy happens when…', ['Gas runs out', 'A call lets the contract be invoked again before state updates', 'Two wallets share a key', 'A block is reorganised'], 1, 'Update state before making external calls (checks-effects-interactions).')] },
    { id: 'm4', title: 'DeFi, NFTs & Security', blurb: 'Money legos, tokens and staying safe.',
      lessons: [
        L('m4l1', 'DeFi primitives', ['Automated market makers price assets from pool reserves; the constant-product rule keeps x \u00d7 y = k.', 'Liquidity providers can suffer impermanent loss: a value gap versus simply holding when pool prices move.']),
        L('m4l2', 'Staying safe', ['Before signing, read what a transaction approves and verify the contract address. Unlimited token approvals are a common attack path.', 'An NFT is usually a token ID on-chain that points to metadata; the image itself often lives elsewhere.'])],
      quiz: [
        Q('A constant-product AMM keeps which relation?', ['x + y = k', 'x \u00d7 y = k', 'x / y = k', 'x \u2212 y = k'], 1, 'Trades move along the x \u00d7 y = k curve, which sets price.'),
        Q('Impermanent loss is…', ['A hack of the pool', 'A fee charged by the wallet', 'Value gap versus holding when prices move', 'Gas refunded'], 2, 'It is the opportunity cost relative to holding the same assets.'),
        Q('Safest habit before signing?', ['Click fast to beat gas', 'Read the approval and verify the contract', 'Share your seed with support', 'Approve unlimited amounts'], 1, 'Most drains come from approvals users did not read.'),
        Q('An NFT typically stores…', ['A token ID with a pointer to metadata', 'The full image on-chain', 'Your private key', 'A legal title'], 0, 'The media is commonly off-chain, referenced by a URI.')] }
  ]
}
