import { useCallback, useEffect, useRef, useState } from 'react'
import { COURSE } from './data/course.js'
import * as P from './logic/progress.js'
import { loadProgress, saveProgress, clearProgress } from './logic/storage.js'
import { issueCertificate, certificateHtml } from './logic/certificate.js'
import { Ring, ChainNav, LessonView, QuizView, CertificateView } from './components.jsx'

const WARN = {
  corrupt: 'Saved progress was unreadable, so you are starting fresh.',
  repaired: 'Some saved progress did not follow the unlock rules and was removed.',
  unavailable: 'Browser storage is blocked: progress works now but will not be saved.'
}

// Main component: poori app ka state aur logical functns ka kaam:
export default function App() {
  const [s, setS] = useState(null), [status, setStatus] = useState('loading')
  const [view, setView] = useState({ t: 'lesson', id: 'm1l1' }), [msg, setMsg] = useState(''), [saveFail, setSaveFail] = useState(false)
  const [menu, setMenu] = useState(false), main = useRef(null)

  // Page khulte hi saved progress load kiya yaha pe:
  useEffect(() => { const r = loadProgress(); setS(r.state); setStatus(r.status); setView(P.resumeView(r.state)) }, [])
  // Progress badalte hi automatically save kiye:
  useEffect(() => { if (s) setSaveFail(!saveProgress(s)) }, [s])

  // Dusre page par jao aur heading par focus le jao (keyboard/screen reader ke liye):
  const go = useCallback(v => { setView(v); setMenu(false); setMsg(''); setTimeout(() => main.current?.querySelector('h1')?.focus(), 0) }, [])
  // Logic layer ka function chalao; error aaye to message show karta hai aur state update nahi hota
  const run = fn => { try { const n = fn(s); setS(n); return n } catch (e) { setMsg(e.message); return null } }

  // Jab tak saved progress load ho raha hai tab tak loading dikhao screen pe:
  if (!s) return <div className="boot" role="status" aria-live="polite"><span className="spin" />Reading your chain…</div>

  // Progress har render par asli data se calculate hota hai
  const pr = P.getProgress(s)
  const mod = COURSE.modules.find(m => m.id === (view.t === 'lesson' ? view.id.slice(0, 2) : view.id))
  const lesson = view.t === 'lesson' ? mod?.lessons.find(l => l.id === view.id) : null

  const complete = id => { const n = run(x => P.completeLesson(x, id)); if (n) setMsg('Lesson sealed into your progress.') }
  const submit = (mid, answers) => { try { const g = P.gradeQuiz(mid, answers); run(x => P.submitQuiz(x, mid, answers)); return g } catch (e) { setMsg(e.message); return null } }
  const issue = async name => { try { setS(await issueCertificate(s, name)); return '' } catch (e) { return e.message } }
  // Certificate ko HTML file ki tarah download kar sakten hai ye function se:
  const download = c => { const u = URL.createObjectURL(new Blob([certificateHtml(c)], { type: 'text/html' })); const a = Object.assign(document.createElement('a'), { href: u, download: 'chainacademy-certificate.html' }); a.click(); URL.revokeObjectURL(u) }
  const reset = () => { if (window.confirm('Delete all lessons, quiz attempts and your certificate?')) { clearProgress(); setS(P.emptyState()); setStatus('new'); go({ t: 'lesson', id: 'm1l1' }) } }

  return (<>
    <a className="skip" href="#main">Skip to content</a>
    <header className="top">
      <div className="brand"><div><strong>ChainAcademy</strong><small>{COURSE.title}</small></div></div>
      <div className="meter"><Ring percent={pr.percent} /><div><strong>{pr.done} of {pr.total} steps</strong><small>{pr.lessonsDone}/{pr.lessonTotal} lessons · {pr.quizzesPassed}/{pr.quizTotal} quizzes passed</small></div></div>
      <button className="btn menu" aria-expanded={menu} aria-controls="nav" onClick={() => setMenu(m => !m)}>Modules</button>
    </header>
    {(WARN[status] || saveFail) && <p className="banner" role="alert">{WARN[status] || 'Could not save progress to this browser.'}</p>}
    <div className="layout">
      <div id="nav" className={menu ? 'side show' : 'side'}><ChainNav s={s} view={view} go={go} /></div>
      <main id="main" ref={main}>
        <p className="live" role="status" aria-live="polite">{msg}</p>
        {lesson && <LessonView key={lesson.id} s={s} lesson={lesson} mod={mod} onComplete={complete} go={go} />}
        {view.t === 'quiz' && mod && <QuizView key={mod.id} s={s} mod={mod} onSubmit={submit} />}
        {view.t === 'cert' && <CertificateView s={s} onIssue={issue} onDownload={download} onReset={reset} />}
        {!lesson && view.t !== 'quiz' && view.t !== 'cert' && <p className="note warn">That page does not exist. Pick a lesson from the list.</p>}
      </main>
    </div></>)
}
