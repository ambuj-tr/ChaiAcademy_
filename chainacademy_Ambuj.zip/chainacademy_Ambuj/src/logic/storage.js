import { emptyState, sanitizeState } from './progress.js'
// LocalStorage mein data isi key naam se save hota hai
export const KEY = 'chainacademy:progress:v1'
const ls = () => { try { return globalThis.localStorage } catch { return undefined } }

/** status: new | ok | repaired | corrupt | unavailable */
// Saved progress padho. Data kharab ho ya storage band ho to crash nahi hota, khali state milti hai
export function loadProgress(storage = ls()) {
  if (!storage) return { state: emptyState(), status: 'unavailable' }
  let raw
  try { raw = storage.getItem(KEY) } catch { return { state: emptyState(), status: 'unavailable' } }
  if (raw == null) return { state: emptyState(), status: 'new' }
  let parsed
  try { parsed = JSON.parse(raw) } catch { return { state: emptyState(), status: 'corrupt' } }
  const { state, repaired } = sanitizeState(parsed)
  return { state, status: repaired ? 'repaired' : 'ok' }
}
// Progress ko LocalStorage mein save karo; fail hone par false return karta hai
export function saveProgress(state, storage = ls()) {
  try { storage.setItem(KEY, JSON.stringify(state)); return true } catch { return false }
}
// Saved progress delete karo (reset ke liye)
export function clearProgress(storage = ls()) { try { storage.removeItem(KEY); return true } catch { return false } }
