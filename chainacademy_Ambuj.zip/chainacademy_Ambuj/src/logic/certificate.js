import { COURSE } from '../data/course.js'
import { bestScore, certificateEligibility, validateName } from './progress.js'

// Browser ke built-in crypto se text ka SHA-256 hash (hex string) banane ke liye use hota hai ye function:
export async function sha256Hex(text) {
  const buf = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('')
}
/** Canonical text that the hash covers. Anyone can re-hash it to verify the certificate. */
// Jis text ka hash banta hai wo yahin banta hai: naam, course, time aur best scores
export function certificateContent(s, name, issuedAt) {
  return [`course:${COURSE.id}`, `title:${COURSE.title}`, `issuer:${COURSE.issuer}`, `learner:${name}`, `completed:${issuedAt}`,
    ...COURSE.modules.map(m => `module:${m.id}:${m.title}:best=${bestScore(s, m.id)}%`)].join('\n')
}
// Certificate tabhi banega jab naam sahi ho aur course poora ho
export async function issueCertificate(s, rawName, now = new Date()) {
  const v = validateName(rawName)
  if (!v.ok) throw new Error(v.error)
  if (!certificateEligibility(s).eligible) throw new Error('Course is not complete yet.')
  const issuedAt = now.toISOString()
  const content = certificateContent(s, v.value, issuedAt)
  return { ...s, learner: v.value, certificate: { name: v.value, issuedAt, content, hash: await sha256Hex(content) } }
}
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
// Download ke liye certificate ki alag HTML file (naam escape hota hai taaki script na chal sake)
export function certificateHtml(c) {
  return `<!doctype html><html lang="en"><meta charset="utf-8"><title>Certificate · ${esc(c.name)}</title><style>body{font:16px Georgia,serif;margin:0;padding:48px;color:#14182b}main{max-width:720px;margin:auto;border:6px double #3b2fd9;padding:48px;text-align:center}h1{font-size:34px;margin:8px 0}h2{font-size:30px;margin:24px 0}code{display:block;word-break:break-all;font-size:12px;margin-top:16px}pre{text-align:left;font-size:12px;background:#f1f3f9;padding:12px;white-space:pre-wrap}</style><main><p>${esc(COURSE.issuer)}</p><h1>Certificate of Completion</h1><p>This certifies that</p><h2>${esc(c.name)}</h2><p>completed <b>${esc(COURSE.title)}</b>: all lessons and all module quizzes at ${COURSE.passMark}% or above.</p><p>Completed ${esc(new Date(c.issuedAt).toUTCString())}</p><code>SHA-256: ${esc(c.hash)}</code><pre>${esc(c.content)}</pre></main></html>`
}
