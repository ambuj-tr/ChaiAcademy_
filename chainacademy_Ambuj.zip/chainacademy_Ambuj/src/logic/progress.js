// Pure progression rules. No React, no storage, no clock side effects: easy to test.
import { COURSE } from '../data/course.js'

// Pass hone ke liye minimum percentage (course.js se aata hai, abhi 75)
export const PASS = COURSE.passMark
const mods = COURSE.modules
const MAX_ATTEMPTS = 50
const HEX64 = /^[0-9a-f]{64}$/

// Naye user ka khali progress: koi lesson complete nahi, koi quiz attempt nahi
export const emptyState = () => ({ version: 1, learner: '', lessons: {}, attempts: {}, certificate: null })
const getModule = id => mods.find(m => m.id === id)

// Check karta hai ki lesson complete hua ya nahi
export const isLessonDone = (s, id) => s.lessons[id] === true
// Is module ke quiz ke saare attempts ki list (nahi hai to khali list)
export const attemptsOf = (s, mid) => s.attempts[mid] || []
// Koi bhi ek attempt pass hai to quiz passed maana jayega
export const isQuizPassed = (s, mid) => attemptsOf(s, mid).some(a => a.passed)
// Sabhi attempts mein se sabse zyada percentage
export const bestScore = (s, mid) => attemptsOf(s, mid).reduce((b, a) => Math.max(b, a.pct), 0)

/** Module N opens only after the quiz of module N-1 is passed. Module 1 is always open. */
// Pehla module hamesha khula hai; baaki tab khulte hain jab pichle module ka quiz pass ho
export function isModuleUnlocked(s, mid) {
  const i = mods.findIndex(m => m.id === mid)
  return i === 0 || (i > 0 && isQuizPassed(s, mods[i - 1].id))
}
/** Lesson k opens when its module is open and lesson k-1 of that module is complete. */
// Lesson tab khulta hai jab uska module khula ho aur pichla lesson complete ho
export function isLessonUnlocked(s, lid) {
  for (const m of mods) {
    const j = m.lessons.findIndex(l => l.id === lid)
    if (j >= 0) return isModuleUnlocked(s, m.id) && (j === 0 || isLessonDone(s, m.lessons[j - 1].id))
  }
  return false
}
// Module ke saare lessons complete hain ya nahi
export const allLessonsDone = (s, mid) => !!getModule(mid) && getModule(mid).lessons.every(l => isLessonDone(s, l.id))
// Quiz tab khulta hai jab module khula ho aur saare lessons complete hon
export const isQuizUnlocked = (s, mid) => isModuleUnlocked(s, mid) && allLessonsDone(s, mid)

// Lesson complete mark karta hai; rule todne par error throw karta hai (lesson skip nahi kar sakte)
export function completeLesson(s, lid) {
  if (!mods.some(m => m.lessons.some(l => l.id === lid))) throw new Error('Unknown lesson.')
  if (!isLessonUnlocked(s, lid)) throw new Error('Finish the previous lesson (and pass the previous quiz) first.')
  return { ...s, lessons: { ...s.lessons, [lid]: true } }
}

/** Grades without mutating anything. Throws on malformed answers. */
// Quiz ke answers check karke score nikalta hai. Ye state change nahi karta
export function gradeQuiz(mid, answers) {
  const m = getModule(mid)
  if (!m) throw new Error('Unknown module.')
  if (!Array.isArray(answers) || answers.length !== m.quiz.length) throw new Error('Answer every question before submitting.')
  const results = m.quiz.map((q, i) => {
    const a = answers[i]
    if (!Number.isInteger(a) || a < 0 || a >= q.options.length) throw new Error(`Answer ${i + 1} is not a valid option.`)
    return { ok: a === q.answer, chosen: a, answer: q.answer, why: q.why }
  })
  const correct = results.filter(r => r.ok).length
  const total = m.quiz.length
  return { results, correct, total, pct: Math.round((correct * 1000) / total) / 10, passed: correct * 100 >= PASS * total }
}

// Quiz submit: pehle lock check, phir grading, phir naya attempt history mein jodta hai
export function submitQuiz(s, mid, answers, now = new Date()) {
  if (!isQuizUnlocked(s, mid)) throw new Error('Complete every lesson in this module before taking its quiz.')
  const g = gradeQuiz(mid, answers)
  const attempt = { at: now.toISOString(), score: g.correct, total: g.total, pct: g.pct, passed: g.passed }
  return { ...s, attempts: { ...s.attempts, [mid]: [...attemptsOf(s, mid), attempt] } }
}

// Progress % asli completed lessons + passed quizzes se nikalta hai (hardcoded nahi)
export function getProgress(s) {
  const lessonTotal = mods.reduce((n, m) => n + m.lessons.length, 0)
  const lessonsDone = mods.reduce((n, m) => n + m.lessons.filter(l => isLessonDone(s, l.id)).length, 0)
  const quizzesPassed = mods.filter(m => isQuizPassed(s, m.id)).length
  const total = lessonTotal + mods.length
  const done = lessonsDone + quizzesPassed
  return { lessonsDone, lessonTotal, quizzesPassed, quizTotal: mods.length, done, total, percent: Math.round((done * 100) / total) }
}

// Certificate ke liye kya baaki hai uski list; list khali ho to eligible
export function certificateEligibility(s) {
  const reasons = []
  for (const m of mods) {
    const left = m.lessons.filter(l => !isLessonDone(s, l.id)).length
    if (left) reasons.push(`${m.title}: ${left} lesson${left > 1 ? 's' : ''} left`)
    if (!isQuizPassed(s, m.id)) reasons.push(`${m.title}: quiz not passed (need ${PASS}%)`)
  }
  return { eligible: reasons.length === 0, reasons }
}

// Naam ki validation: extra spaces hatao, length aur allowed characters check karo
export function validateName(input) {
  if (typeof input !== 'string') return { ok: false, error: 'Enter your name.' }
  const value = input.trim().replace(/\s+/g, ' ')
  if (value.length < 2) return { ok: false, error: 'Name must be at least 2 characters.' }
  if (value.length > 60) return { ok: false, error: 'Name must be 60 characters or fewer.' }
  if (!/^[\p{L}][\p{L}\p{M} .'\-]*$/u.test(value)) return { ok: false, error: 'Use letters, spaces, dots, apostrophes or hyphens only.' }
  return { ok: true, value }
}

// Page reload par wahin se shuru karo jahan user ruka tha
export function resumeView(s) {
  for (const m of mods) {
    for (const l of m.lessons) if (!isLessonDone(s, l.id)) return { t: 'lesson', id: l.id }
    if (!isQuizPassed(s, m.id)) return { t: 'quiz', id: m.id }
  }
  return { t: 'cert' }
}

/**
 * Rebuilds a trustworthy state from untrusted saved data. Walks the course in order and
 * keeps only what the rules could actually have produced (no skipped lessons, no attempts
 * for locked quizzes). `passed` is recomputed from the score, never trusted.
 */
// LocalStorage ka data bharosemand nahi (koi edit kar sakta hai), isliye rules ke hisaab se dobara banate hain
export function sanitizeState(raw) {
  const clean = emptyState()
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { state: clean, repaired: true }
  if (typeof raw.learner === 'string') clean.learner = raw.learner.trim().slice(0, 60)
  const rl = raw.lessons && typeof raw.lessons === 'object' ? raw.lessons : {}
  const ra = raw.attempts && typeof raw.attempts === 'object' ? raw.attempts : {}
  for (const m of mods) {
    let all = true
    for (const l of m.lessons) { if (rl[l.id] === true) clean.lessons[l.id] = true; else { all = false; break } }
    if (!all) break
    const list = Array.isArray(ra[m.id]) ? ra[m.id] : []
    const ok = list.filter(a => a && Number.isInteger(a.score) && Number.isInteger(a.total) && a.total === m.quiz.length && a.score >= 0 && a.score <= a.total && typeof a.at === 'string')
      .slice(-MAX_ATTEMPTS).map(a => ({ at: a.at, score: a.score, total: a.total, pct: Math.round((a.score * 1000) / a.total) / 10, passed: a.score * 100 >= PASS * a.total }))
    if (ok.length) clean.attempts[m.id] = ok
    if (!ok.some(a => a.passed)) break
  }
  const c = raw.certificate
  if (c && typeof c.name === 'string' && typeof c.issuedAt === 'string' && typeof c.content === 'string' && HEX64.test(c.hash) && certificateEligibility(clean).eligible)
    clean.certificate = { name: c.name, issuedAt: c.issuedAt, content: c.content, hash: c.hash }
  return { state: clean, repaired: JSON.stringify(clean) !== JSON.stringify(raw) }
}
