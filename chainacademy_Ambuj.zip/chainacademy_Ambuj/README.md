# ChainAcademy – Web3 Learning Progress Engine

ChainAcademy is a simple React + Vite app for learning Web3 through lessons and quizzes. It tracks progress and provides a printable completion certificate with a SHA-256 hash.

## Features
- 4 learning modules with sequential lesson unlocking
- Quizzes with a 75% pass mark, retries, and score history
- Progress saved in the browser using `localStorage`
- Progress percentage calculated from completed lessons and passed quizzes
- Printable certificate with learner details, completion time, and SHA-256 hash
- Simple, responsive white theme

## Project Pipeline
1. `src/data/course.js` contains the modules, lessons, and quiz questions.
2. `src/logic/progress.js` checks prerequisites, grades quizzes, and calculates progress.
3. `src/logic/storage.js` saves and loads progress from `localStorage`.
4. `src/logic/certificate.js` checks eligibility and creates the certificate and hash.
5. `src/components.jsx` contains the UI components; `src/App.jsx` manages app state and screens.
6. `src/styles.css` controls the page layout and visual theme.

## Run Locally
Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal, usually `http://localhost:5173`.

## Test and Build
```bash
npm test
npm run build
npm run preview
```

## Deployment
Push the project to GitHub, import the repository into Vercel, and deploy with the default Vite settings. The build command is `npm run build` and the output folder is `dist`.

## AI Assistance
AI assistance was used for minor styling and UI-related improvements in `src/styles.css` and `src/App.jsx`.
