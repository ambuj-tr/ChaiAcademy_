import { describe, it, expect } from 'vitest'
import { COURSE } from '../src/data/course.js'
import * as P from '../src/logic/progress.js'
import { loadProgress, saveProgress, KEY } from '../src/logic/storage.js'
import { sha256Hex, issueCertificate, certificateContent } from '../src/logic/certificate.js'

const mem = (init) => { const d = new Map(init ? [[KEY, init]] : []); return { getItem: k => d.get(k) ?? null, setItem: (k, v) => d.set(k, v), removeItem: k => d.delete(k) } }
const perfect = mid => COURSE.modules.find(m => m.id === mid).quiz.map(q => q.answer)
const wrong = (mid, n) => COURSE.modules.find(m => m.id === mid).quiz.map((q, i) => (i < n ? q.answer : (q.answer + 1) % q.options.length))
function finishModule(s, i, answers) { const m = COURSE.modules[i]; m.lessons.forEach(l => (s = P.completeLesson(s, l.id))); return P.submitQuiz(s, m.id, answers ?? perfect(m.id)) }
const full = () => COURSE.modules.reduce((s, _, i) => finishModule(s, i), P.emptyState())

describe('unlocking', () => {
  it('opens only the first lesson of module 1 initially', () => {
    const s = P.emptyState()
    expect(P.isLessonUnlocked(s, 'm1l1')).toBe(true)
    expect(P.isLessonUnlocked(s, 'm1l2')).toBe(false)
    expect(P.isModuleUnlocked(s, 'm2')).toBe(false)
  })
  it('rejects skipping a lesson and unknown lessons', () => {
    expect(() => P.completeLesson(P.emptyState(), 'm1l2')).toThrow()
    expect(() => P.completeLesson(P.emptyState(), 'nope')).toThrow()
  })
  it('keeps module 2 locked until module 1 quiz is PASSED', () => {
    let s = finishModule(P.emptyState(), 0, wrong('m1', 2))
    expect(P.isModuleUnlocked(s, 'm2')).toBe(false)
    expect(() => P.completeLesson(s, 'm2l1')).toThrow()
    s = P.submitQuiz(s, 'm1', perfect('m1'))
    expect(P.isLessonUnlocked(s, 'm2l1')).toBe(true)
  })
  it('blocks the quiz until all lessons are done', () => {
    const s = P.completeLesson(P.emptyState(), 'm1l1')
    expect(() => P.submitQuiz(s, 'm1', perfect('m1'))).toThrow(/lesson/i)
  })
})

describe('quiz scoring and retries', () => {
  it('passes at exactly 75% (3/4) and fails at 50%', () => {
    expect(P.gradeQuiz('m1', wrong('m1', 3))).toMatchObject({ correct: 3, pct: 75, passed: true })
    expect(P.gradeQuiz('m1', wrong('m1', 2))).toMatchObject({ pct: 50, passed: false })
  })
  it('records every attempt, keeps best score, allows retry after failing', () => {
    let s = finishModule(P.emptyState(), 0, wrong('m1', 1))
    s = P.submitQuiz(s, 'm1', wrong('m1', 2))
    expect(P.isQuizPassed(s, 'm1')).toBe(false)
    s = P.submitQuiz(s, 'm1', perfect('m1'))
    expect(P.attemptsOf(s, 'm1').map(a => a.pct)).toEqual([25, 50, 100])
    expect(P.bestScore(s, 'm1')).toBe(100)
    expect(P.isQuizPassed(s, 'm1')).toBe(true)
  })
  it('a worse retake never removes a pass', () => {
    let s = finishModule(P.emptyState(), 0)
    s = P.submitQuiz(s, 'm1', wrong('m1', 0))
    expect(P.isQuizPassed(s, 'm1')).toBe(true)
  })
  it.each([[[0, 1]], [[0, 1, 2, 9]], [[0, 1, 2, -1]], [[0, 1, 2, 1.5]], [[0, 1, 2, null]], ['abc'], [undefined]])('rejects invalid answers %j', a => {
    const s = finishModule(P.emptyState(), 0)
    expect(() => P.submitQuiz(s, 'm1', a)).toThrow()
  })
  it('does not mutate the previous state', () => {
    const s = finishModule(P.emptyState(), 0); const snap = JSON.stringify(s)
    P.submitQuiz(s, 'm1', perfect('m1')); expect(JSON.stringify(s)).toBe(snap)
  })
})

describe('progress calculation', () => {
  it('is 0% when empty and derived from real completions', () => {
    expect(P.getProgress(P.emptyState()).percent).toBe(0)
    const s = P.completeLesson(P.emptyState(), 'm1l1')
    expect(P.getProgress(s)).toMatchObject({ done: 1, total: 12, percent: 8 })
  })
  it('counts a quiz only when passed', () => {
    const failed = finishModule(P.emptyState(), 0, wrong('m1', 1))
    expect(P.getProgress(failed)).toMatchObject({ lessonsDone: 2, quizzesPassed: 0, percent: 17 })
    expect(P.getProgress(P.submitQuiz(failed, 'm1', perfect('m1'))).percent).toBe(25)
  })
  it('is 100% only for a full course', () => expect(P.getProgress(full()).percent).toBe(100))
})

describe('persistence and invalid saved state', () => {
  it('round-trips through storage', () => {
    const st = mem(); const s = finishModule(P.emptyState(), 0)
    expect(saveProgress(s, st)).toBe(true)
    const r = loadProgress(st); expect(r.status).toBe('ok'); expect(r.state).toEqual(s)
  })
  it('starts fresh when nothing is saved', () => expect(loadProgress(mem()).status).toBe('new'))
  it.each(['{not json', '"str"', '[]', 'null', '123'])('recovers from corrupted data %s', raw => {
    const r = loadProgress(mem(raw)); expect(P.getProgress(r.state).percent).toBe(0)
    expect(['corrupt', 'repaired']).toContain(r.status)
  })
  it('rejects tampered progress that skips locked content', () => {
    const forged = { lessons: { m1l2: true, m3l1: true, m4l2: true }, attempts: { m2: [{ at: 'x', score: 4, total: 4, pct: 100, passed: true }] } }
    const r = loadProgress(mem(JSON.stringify(forged)))
    expect(r.status).toBe('repaired'); expect(r.state.lessons).toEqual({}); expect(r.state.attempts).toEqual({})
  })
  it('recomputes "passed" from the score instead of trusting it', () => {
    const s = finishModule(P.emptyState(), 0, wrong('m1', 1)); const forged = structuredClone(s)
    forged.attempts.m1[0].passed = true
    expect(P.isQuizPassed(loadProgress(mem(JSON.stringify(forged))).state, 'm1')).toBe(false)
  })
  it('survives unavailable storage', () => {
    const broken = { getItem() { throw new Error('denied') }, setItem() { throw new Error('quota') } }
    expect(loadProgress(broken).status).toBe('unavailable'); expect(saveProgress(P.emptyState(), broken)).toBe(false)
  })
})

describe('certificate', () => {
  it('sha256 matches the known vector', async () => expect(await sha256Hex('abc')).toBe('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'))
  it('is not eligible when quizzes or lessons are missing', () => {
    const e = P.certificateEligibility(finishModule(P.emptyState(), 0, wrong('m1', 1)))
    expect(e.eligible).toBe(false); expect(e.reasons.length).toBeGreaterThan(5)
  })
  it('refuses to issue when incomplete or with an invalid name', async () => {
    await expect(issueCertificate(P.emptyState(), 'Ada Lovelace')).rejects.toThrow()
    await expect(issueCertificate(full(), '   ')).rejects.toThrow()
    await expect(issueCertificate(full(), '<script>')).rejects.toThrow()
  })
  it('issues a verifiable certificate and it survives reload', async () => {
    const s = await issueCertificate(full(), '  Ada   Lovelace ', new Date('2026-01-02T03:04:05Z'))
    expect(s.certificate.name).toBe('Ada Lovelace')
    expect(s.certificate.hash).toBe(await sha256Hex(certificateContent(s, 'Ada Lovelace', '2026-01-02T03:04:05.000Z')))
    const st = mem(); saveProgress(s, st); expect(loadProgress(st).state.certificate.hash).toBe(s.certificate.hash)
  })
  it('drops a saved certificate if progress is no longer complete', async () => {
    const s = await issueCertificate(full(), 'Ada Lovelace'); const bad = { ...s, lessons: { m1l1: true } }
    expect(loadProgress(mem(JSON.stringify(bad))).state.certificate).toBeNull()
  })
})
