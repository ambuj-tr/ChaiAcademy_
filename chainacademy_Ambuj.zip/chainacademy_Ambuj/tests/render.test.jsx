import { describe, it, expect } from 'vitest'
import { renderToString as R } from 'react-dom/server'
import { COURSE } from '../src/data/course.js'
import * as P from '../src/logic/progress.js'
import { issueCertificate, certificateHtml } from '../src/logic/certificate.js'
import { ChainNav, LessonView, QuizView, CertificateView } from '../src/components.jsx'

const m1 = COURSE.modules[0]
const done = (s, m) => { m.lessons.forEach(l => (s = P.completeLesson(s, l.id))); return P.submitQuiz(s, m.id, m.quiz.map(q => q.answer)) }
const noop = () => {}

describe('views render in every state', () => {
  it('locks later modules, lessons and quiz at the start', () => {
    const html = R(<ChainNav s={P.emptyState()} view={{ t: 'lesson', id: 'm1l1' }} go={noop} />)
    expect((html.match(/disabled=""/g) || []).length).toBe(11)   // 12 steps + certificate button, minus first lesson
    expect(html).toContain('Pass the quiz in')
  })
  it('shows a locked message for a locked lesson and quiz', () => {
    expect(R(<LessonView s={P.emptyState()} lesson={m1.lessons[1]} mod={m1} onComplete={noop} go={noop} />)).toContain('locked')
    expect(R(<QuizView s={P.emptyState()} mod={m1} onSubmit={noop} />)).toContain('Finish every lesson')
  })
  it('renders quiz history and a disabled submit button', () => {
    const s = done(P.emptyState(), m1)
    const html = R(<QuizView s={s} mod={m1} onSubmit={noop} />).replace(/<!-- -->/g, '')
    expect(html).toContain('Attempt 1: 4/4'); expect(html).toMatch(/<button[^>]*disabled[^>]*>Submit answers/)
  })
  it('certificate view lists reasons when ineligible', () => {
    const html = R(<CertificateView s={P.emptyState()} onIssue={noop} onDownload={noop} onReset={noop} />)
    expect(html).toContain('Not yet eligible'); expect(html).toContain('quiz not passed')
  })
  it('certificate html escapes the learner name', () => {
    expect(certificateHtml({ name: '<img onerror=x>', issuedAt: '2026-01-01T00:00:00Z', hash: 'a'.repeat(64), content: 'x' })).not.toContain('<img onerror')
  })
  it('full course renders the certificate with its hash', async () => {
    let s = P.emptyState(); COURSE.modules.forEach(m => (s = done(s, m)))
    s = await issueCertificate(s, 'Grace Hopper')
    const html = R(<CertificateView s={s} onIssue={noop} onDownload={noop} onReset={noop} />)
    expect(html).toContain('Grace Hopper'); expect(html).toContain(s.certificate.hash)
  })
})
